<div class="list-group">
	<?php echo $regimens;?>
</div>