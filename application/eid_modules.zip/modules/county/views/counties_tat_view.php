<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default">
		  <div class="panel-heading" id="heading">
		  	County TAT Outcomes <div class="display_date"></div>
		  </div>
		  <div class="panel-body" id="county_tat_outcomes">
		    <center><div class="loader"></div></center>
		  </div>
		</div>
	</div>
</div>


<?php $this->load->view('county_tat_view_footer'); ?>