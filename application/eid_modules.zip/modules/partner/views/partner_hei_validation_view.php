<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default">
		  <div class="panel-heading" style="min-height: 5em;">
		  	<div class="col-sm-4">
			    HEI Validations
			    <div class="display_date"></div>
			</div>
		  </div>
		  <div class="panel-body" id="hei_validation_table">
		    <center><div class="loader"></div></center>
		  </div>
		</div>
	</div>
</div>

<?= @$this->load->view('partner_hei_validation_footer_view'); ?>