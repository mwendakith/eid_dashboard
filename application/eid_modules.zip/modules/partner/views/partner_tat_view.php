<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default">
		  <div class="panel-heading" id="heading">
		  	Partner TAT Outcomes <div class="display_date"></div>
		  </div>
		  <div class="panel-body" id="partner_tat_outcomes">
		    <center><div class="loader"></div></center>
		  </div>
		</div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default">
		  <div class="panel-heading" id="heading">
		  	Partner TAT Details <div class="display_date"></div>
		  </div>
		  <div class="panel-body" id="partner_tat_details">
		    <center><div class="loader"></div></center>
		  </div>
		</div>
	</div>
</div>


<?php $this->load->view('partner_tat_view_footer'); ?>