<?php $siteKey = '6LfymQsUAAAAAG7YlfJ12gGnmFNRUZJ6JSkPEFiT';
$lang = 'en';?>
<div class="row">
	<div class="btn-group">
		<a href="<?php echo base_url();?>survey"> <button type="button" class="btn btn-primary">Fill In Survey Details </button> </a>
		<a href="<?php echo base_url();?>survey/surveys"> <button type="button" class="btn btn-primary">My Survey Listing </button> </a>
		<a href="<?php echo base_url();?>survey/view_surveys"> <button type="button" class="btn btn-primary">View Surveys </button> </a>	
		<a href="<?php echo base_url();?>survey/logout"> <button type="button" class="btn btn-primary">Logout </button> </a>			
	</div>
</div>