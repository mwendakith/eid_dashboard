<div class="list-group">
	<?php echo $facilities;?>
</div>
