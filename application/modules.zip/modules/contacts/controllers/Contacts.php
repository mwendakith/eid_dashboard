<?php
defined('BASEPATH') or exit('No direct script access allowed!');

/**
* 
*/
class Contacts extends MY_Controller
{
	public $data = array();
	
	function __construct()
	{
		parent::__construct();
		$this->data	=	array_merge($this->data,$this->load_libraries(array('material','custom')));
		$this->data['contacts'] = TRUE;
	}

	function index()
	{
		$this->data['content_view'] = 'contacts/contacts_view';
		// echo "<pre>";print_r($this->data);die();
		$this -> template($this->data);
	}

	function submit()
	{
		
	}
}
?>