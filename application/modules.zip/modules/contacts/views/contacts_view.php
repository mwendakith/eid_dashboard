<div class="row">
	<div class="col-md-4 offset-md-4">
	<center>
		<form action="<?php base_url();?>contacts/submit" method="post">
			<div class="form-group">
				<label for="inputName">Name:</label>
				<input type="text" class="form-control" id="inputName" name="inputName" aria-describedby="textHelp" placeholder="Enter Your Names">
			</div>
			<div class="form-group">
				<label for="InputEmail1">Email address</label>
				<input type="email" class="form-control" id="InputEmail1" name="InputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
				<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
			</div>
			<div class="form-group">
				<label for="InputPhone">Phone:</label>
				<input type="text" class="form-control" id="InputPhone" name="InputPhone" placeholder="0722000111">
			</div>
			<div class="form-group">
				<label for="InputSubject">Subject:</label>
				<input type="text" class="form-control" id="InputSubject" name="InputSubject" placeholder="Enter Subject">
			</div>

			<div class="form-group">
				<label for="message">Message</label>
				<textarea class="form-control" id="message" name="message" rows="3"></textarea>
			</div>
			
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</center>
	</div>
</div>