<script type="text/javascript">
	$().ready(function(){
		
	});
</script>